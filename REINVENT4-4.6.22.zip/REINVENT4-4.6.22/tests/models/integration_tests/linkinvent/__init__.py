from tests.models.integration_tests.linkinvent.model_tests import *
