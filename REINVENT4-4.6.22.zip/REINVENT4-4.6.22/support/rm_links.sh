#!/bin/sh
#
# Remove symlinks
# Run in top level
#

rm -f reinvent_models
rm -f reinvent/models/reinvent_core
rm -f reinvent/models/lib_invent
rm -f reinvent/models/link_invent
rm -f reinvent/models/molformer
