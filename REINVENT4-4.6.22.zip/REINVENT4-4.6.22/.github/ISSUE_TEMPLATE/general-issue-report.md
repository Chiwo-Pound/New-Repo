---
name: General issue report
about: General template for any issue.
title: ''
labels: ''
assignees: ''

---

When you report issues please provide the log file and any input files to REINVENT.  We understand that you may not always be able to do so but provide as much of the files as possible.  This will help diagnosing your problem tremendously.
