Prior models
------------

All public prior models can be found on [Zenodo](https://doi.org/10.5281/zenodo.15641296).
