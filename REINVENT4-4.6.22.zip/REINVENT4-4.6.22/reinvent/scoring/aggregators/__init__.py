"""Aggregator functions"""

from .means import *
