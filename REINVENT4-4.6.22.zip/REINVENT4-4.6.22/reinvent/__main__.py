from .Reinvent import main_script

main_script()
