from dataclasses import dataclass


@dataclass
class LeavingGroupsDTO:
    leaving_group_scaffold: str
    leaving_group_decoration: str
