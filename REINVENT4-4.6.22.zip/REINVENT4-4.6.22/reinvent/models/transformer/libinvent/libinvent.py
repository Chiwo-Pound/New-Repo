from reinvent.models.transformer.transformer import TransformerModel


class LibinventModel(TransformerModel):

    _model_type = "Libinvent"
    _version = 2
