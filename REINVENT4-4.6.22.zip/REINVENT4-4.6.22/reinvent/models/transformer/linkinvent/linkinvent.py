from reinvent.models.transformer.transformer import TransformerModel


class LinkinventModel(TransformerModel):

    _model_type = "Linkinvent"
    _version = 2
