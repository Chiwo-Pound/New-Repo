from reinvent.models.transformer.transformer import TransformerModel


class PepinventModel(TransformerModel):
    _model_type = "Pepinvent"
    _version = 1
