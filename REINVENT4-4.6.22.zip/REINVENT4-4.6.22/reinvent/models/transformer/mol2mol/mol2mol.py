from reinvent.models.transformer.transformer import TransformerModel


class Mol2MolModel(TransformerModel):

    _model_type = "Mol2Mol"
    _version = 1
