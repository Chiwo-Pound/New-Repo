from reinvent.models.transformer.core.vocabulary import Vocabulary

__all__ = [Vocabulary]
