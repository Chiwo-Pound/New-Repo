"""The scoring functionality for REINVENT."""
