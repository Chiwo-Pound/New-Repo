"""Create empty models for REINVENT"""
