from .preprocess import main_script

main_script()
